<?php
function connect_sql()
{
    $user = 'veriga';
    $pass = 'gfhjkm';

    $dsn = 'mysql:dbname=test_db;host=127.0.0.1';
    global $db;
    try {

        $db = new PDO($dsn, $user, $pass);
    } catch (PDOException $e) {
        echo 'Подключение не удалось: ' . $e->getMessage();
    }
    $GLOBALS['db'] = $db;
}

function is_cookie()
{
    if (isset($_COOKIE['counter']) && isset($_COOKIE['index_question']) && $_COOKIE['id']) {
        $_SESSION['counter'] = $_COOKIE['counter'];
        $_SESSION['index_question'] = $_COOKIE['index_question'];
        $_SESSION['id'] = $_COOKIE['id'];
    }
}

function next_answer()
{
    $db = $GLOBALS['db'];
    // індекс питання, вибрано зі змішаного масиву
    $index_question = $_SESSION['index_question'][$_SESSION['counter']];
    // відповідь до  питання з індексом
    //тут перевіряємо якщо користувач любить оновлювати сторінку
    // то не приймати оновлення сторіки як відповідь
    // відповідь приймається тільки тоді коли натиснута кнопка далі
    if ($index_question == $_POST['counter']) {
        if ($_POST['question_tru'] == $_POST[$index_question])
            $db->query("UPDATE result SET true_answer = true_answer + 1 WHERE id=" . $_SESSION['id'] . ";")
            or die('Помилка створення запису результатів тесту');
        $_SESSION['counter']++;
    }
}

function test_over()
{
    $db = $GLOBALS['db'];
    if (!isset($_COOKIE['counter']) && !isset($_COOKIE['answer'])) {
        setcookie('counter', $_SESSION['counter'], time() + 60 * 60 * 24 * 7);
        setcookie('id', $_SESSION['id'], time() + 60 * 60 * 24 * 7);
    }
    $_SESSION['exit'] = true;
    $data = $db->query("SELECT true_answer FROM result WHERE id=" . $_SESSION['id'] . ";")
    or die('Помилка зчитування результату');
    $array_true = $data->fetch();
    $true = $array_true['true_answer'];
    echo 'Вітаю, ви пройшли тест!<br>';
    echo 'Правильних відповідей - ' . $true . '<br>';
    echo 'Неправильних відповідей - ' . (5 - $true) . '<br>';
    echo 'Набрано зі 100 балів - ' . ($true) / count($_SESSION['index_question']) * 100 . '<br>';
}

function next_question()
{
    $db = $GLOBALS['db'];
    // індекс питання, вибрано зі змішаного масиву
    $index_question = $_SESSION['index_question'][$_SESSION['counter']];
    $array_variant = array();
    // масив варіантів
    $data = $db->query("SELECT v.id, v.answer
                            FROM variant v INNER JOIN questions q
                            ON v.id_question = q.id WHERE q.id =" . $index_question . ";")
    or die('Помилка зчитування варіантів запитань');
    $result = $data->fetchALL();
    foreach ($result as $row) {
        $array_variant[] = $row;
    }
    shuffle($array_variant);

    // саме запитання та ід вірного варіанта
    $data = $db->query("SELECT question, tru_id_v FROM questions WHERE id=" . $index_question . ";")
    or die('Помилка зчитування запитання');
    $result = $data->fetch();

    echo '<form action = ' . $_SERVER['PHP_SELF'] . ' method="post">';
    echo '<p><b>' . $result['question'] . '</b></p>';
    echo '<input type="hidden" name="question_tru" value="' . $result['tru_id_v'] . '">';
    echo '<input type="hidden" name="counter" value="' . $index_question . '">';

    foreach ($array_variant as $variant) {
        $name_v = 'variant' . $variant['id'];
        echo '<input type="radio" name="' . $index_question . '" id="' . $name_v . '" value="' . $variant['id'] . '">';
        echo '<label for="' . $name_v . '">' . $variant['answer'] . '</label><br/>';
    }

    echo '<input type="submit" name="next" value="Далі">';
    echo '</form>';
}